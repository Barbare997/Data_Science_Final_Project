"""
Urban Pulse - Predicting City Traffic Stress

This package contains modules for data processing, visualization, and machine learning.
"""

__version__ = "1.0.0"

